#!/bin/bash

echo "Installing rotaryencoder Dependencies"

echo "No additional packages needed."
echo "Continuing..."

#requred to end the plugin install
echo "plugininstallend"
