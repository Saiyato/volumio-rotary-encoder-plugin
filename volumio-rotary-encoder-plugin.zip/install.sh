#!/bin/bash

echo "Installing Rotary Encoder and its dependencies"

echo "No additional packages needed."
echo "Continuing..."

#requred to end the plugin install
echo "plugininstallend"
